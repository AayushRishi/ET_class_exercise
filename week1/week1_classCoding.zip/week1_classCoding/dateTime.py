import datetime


def main():
    print("This program displays current Date and Time.")
    print(datetime.datetime.now())


main()
